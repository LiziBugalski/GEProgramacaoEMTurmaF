# GEProgramacaoEMTurmaF

**Projeto Inicial:** Aprender a usar o Github e  compreender suas funcionalidades;

__*Evolução do Projeto*__: Utilizar o Github como ferramenta Pedagógica no ensino de Programação e de Pensamento Computacional;

__*Pré-requisitos*__: Criar o perfil na plataforma e aprender as funcionalidades básicas para criar repositórios, editá-los e manipulá-los;

__*Colaboradores*:__ Professora ***Fran Pastori*** - Tutora do nosso grupo de estudos, e colegas inscritos na turma 7 desse grupo de estudos.


Para começar a fazer a programação do *Readme* e compreender a utilização dos códigos necessários para o desenvolvimento da linguagem, coloquei a imagem e o link de um filme muito especial do **Tim Burton**

[![](https://disneyplusbrasil.com.br/wp-content/uploads/2021/10/O-Estranho-Mundo-de-Jack-Disney-Plus.jpg)](https://www.youtube.com/watch?v=4-vYO1wW2yo)
